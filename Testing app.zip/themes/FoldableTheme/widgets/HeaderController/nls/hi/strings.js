define({
  "_widgetLabel": "हैडर नियंत्रक",
  "signin": "साइन इन करें",
  "signout": "साइन आउट करें",
  "about": "बारे में",
  "signInTo": "यहाँ साइन इन करें",
  "cantSignOutTip": "यह फंक्शन पूर्वावलोकन मोड में N/A है।",
  "more": "अधिक"
});