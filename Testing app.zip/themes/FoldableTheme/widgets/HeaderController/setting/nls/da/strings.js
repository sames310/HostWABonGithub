define({
  "group": "Navn",
  "openAll": "Åbn alle i panelet",
  "dropDown": "Vis i rullemenuen",
  "noGroup": "Der er ingen widget-gruppe angivet.",
  "groupSetLabel": "Angiv egenskaber for widget-grupper"
});