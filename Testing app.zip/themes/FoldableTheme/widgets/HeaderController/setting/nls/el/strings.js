define({
  "group": "Όνομα",
  "openAll": "Άνοιγμα όλων σε ένα πλαίσιο",
  "dropDown": "Εμφάνιση σε αναπτυσσόμενο μενού",
  "noGroup": "Δεν έχει οριστεί ομάδα widget.",
  "groupSetLabel": "Ορισμός ιδιοτήτων ομάδων widget"
});