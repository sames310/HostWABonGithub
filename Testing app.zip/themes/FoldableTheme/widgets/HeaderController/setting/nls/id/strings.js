define({
  "group": "Nama",
  "openAll": "Buka semua dalam satu panel",
  "dropDown": "Tampilkan di menu tarik-turun",
  "noGroup": "Tidak ada aturan grup widget.",
  "groupSetLabel": "Tetapkan properti grup widget"
});